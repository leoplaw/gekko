module.exports = {
  presets: [
    '@vue/app'
  ],
  ignore: [
    'node_modules',
  ],
  plugins : ["transform-commonjs-es2015-modules"]
}
